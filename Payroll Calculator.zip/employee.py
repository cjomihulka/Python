# -*- coding: utf-8 -*-
"""
Created on Thu Nov  5 09:30:39 2020

@author: Cortney
"""

class Employee:
    #constructor
    def __init__(self, name, empType, hoursWorked):
        self.name = name
        self.empType = empType
        self.hoursWorked = hoursWorked
    #setters
    def setName(self, name):
        self.name = name
    def setType(self, empType):
        self.empType = empType
    def setHrs(self, hoursWorked):
        self.hoursWorked = hoursWorked
    #getters
    def getName(self):
        return self.name
    def getType(self):
        return self.empType
    def getHrs(self):
        return self.hoursWorked
    #calculate weekly pay
    def calculatePay(self, wage):
        regularPay = (wage * 40)
        overtimePay = (1.5 * wage * (self.hoursWorked - 40))
        totalPay=regularPay+overtimePay
        return totalPay 