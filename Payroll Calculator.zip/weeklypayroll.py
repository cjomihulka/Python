# -*- coding: utf-8 -*-
"""
Created on Thu Nov  5 09:31:39 2020

@author: Cortney
"""

from employee import Employee

from supervisor import Supervisor
#read employee name
def getName():
    while True:
        name = input("Enter employee name: ")
        if (name.isalpha() == False):
            print("Invalid name. Please retry.")
            continue
        else:
            return name
#read employee type
def employeeType():
    while True:
        emType = input("Enter s for supervisor and e for regular employee: ")
        if emType.lower() != "s" and emType.lower() != "e":
            print("Invalid type. Please retry.")
            continue
        else:
            return emType
#read number of hours worked
def getHours():
    while True:
        hoursWork = float(input("Enter the number of hours worked: "))
        return hoursWork 
#print employee details
def printData(name,empType,x,pay):
    print ("Employee details")
    print("Name: ",name)
    if(empType.lower() == "e"):
        print("Type: Employee")
        print("Hours worked: ",x)       
    else:
        print("Type: Supervisor")
        print("Yearly salary: ",x)
    print("Weekly pay: ",pay) 
#begin program
def main():   
    while True:       
        name = getName()
        empType = employeeType()
        hoursWork = getHours()
        if(empType.lower()=="e"):
            obj1 = Employee(name,empType,hoursWork)
            hoursWorked = obj1.getHrs()
            pay = obj1.calculatePay(hoursWork)
            printData(name,empType,hoursWorked,pay)
        else:
            obj2 = Supervisor(name,empType,hoursWork)
            salary = obj2.getSalary()
            pay = obj2.calculatePay()
            printData(name,empType,salary,pay)
        userInput = input("Do you want to add another employee (y/n)?")
        if(userInput == "n"):
            return

main() 