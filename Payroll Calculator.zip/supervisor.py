# -*- coding: utf-8 -*-
"""
Created on Thu Nov  5 09:31:23 2020

@author: Cortney
"""

class Supervisor:
    #constructor
    def __init__(self, name, empType, salary):
        self.name = name
        self.empType = empType
        self.salary = salary
    #setters
    def setName(self, name):
        self.name = name
    def setType(self, empType):
        self.empType = empType
    def setSalary(self, salary):
        self.salary = salary
    #getters
    def getName(self):
        return self.name
    def getType(self):
        return self.empType
    def getSalary(self):
       return self.salary
   #calculate weekly pay
    def calculatePay(self):
        weeklyPay = self.salary / 52
        return weeklyPay
    